package cmd

// Execute executes the commands.
func Execute() error {
	return rootCmd.Execute()
}
