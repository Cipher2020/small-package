package files

// Sorting contains a sorting order.
type Sorting struct {
	By  string `json:"by"`
	Asc bool   `json:"asc"`
}
